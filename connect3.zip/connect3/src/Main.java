// Georgian Student Number : 200416930
// Lakehead Student Number : 0877826

import java.util.InputMismatchException;
import java.util.Scanner;

public class Main
{
    /* DECLARING THE GLOBAL VARIABLES */
    private static String[][] three  = new String[5][5]; //The 2D array for the table
    private static String[] title = new String[5];  //The array for the column numbers
    private static boolean active = true;
    private static int playerCol; //Holds the value for what column the player wants to use
    private static String sym; //The string that is used to either the $ symbol or / into the little playing tokens [ ]
    private static String player; //The string that holds which player is playing at any given turn
    private static int turn=1; //Used to count up each turn
    private static int currentRow; //Hold's what the current Row value is
    /*  The following keeps the row number for each respective column
    * (ie A:0, B:1, C:2, D:3, E:4)
    * */
    private static int colA = 4;
    private static int colB = 4;
    private static int colC = 4;
    private static int colD = 4;
    private static int colE = 4;


    public static void main(String[] args)
    {
        /*The following 2 lines go to both methods
         *resulting in the table along with the column
         *numbers being displayed
         */
        title();
        displayTable();
        /*The while loop that keeps the game going until
         * someone wins or there is a tie.
          * */
        while(active) {
            System.out.printf("TURN " + turn + "%n"); //Prints the turn number

            /*The try statement used to handles the main problems that would otherwise
             crash the game, allowing for it to continue
              */
            try{
                {
                    /* The following if and else statements decide what player's turn it is
                     * as well as it assigns the value that the symbol variable will be inserting
                     * into the spot that is picked
                     */

                    if (turn%2==0) {
                        player="PLAYER [$]";
                        sym="[$]";
                    }
                    else{
                        player="PLAYER [/]";
                        sym="[/]";
                    }
                    /*This goes the input table method which gets the move that the player makes
                    and applies it to the three[][] array table
                     */
                    inputTable();
                }
                /*The following goes to the method winChecker which as it sounds like, checks the
                to see if the player's move resulted in any victories, and if not then it returns
                and prints the table again so that it can loop back to the beginning of the while
                loop ready for the next move. If there is a winning move done, the checker returns
                true, and it prints who won and sets active as false, thus stopping the loop from
                starting again.
                 */
                boolean winner = winChecker();
                if(winner){
                    turn--;
                    System.out.printf(player + " WINS!"+"%n");
                    displayTable();
                    active=false;
                }
                if(!winner){
                    title();
                    displayTable();}

            }
            /*These are the 2 catch statements that correspond to the try at the beginning of the
              * main method. These make sure that if the user presses something that would be out
               * of bounds for the array or if they type something that isn't even an integer
               * then it keeps the game going and just says that they need to put something
               * valid*/
            catch(InputMismatchException r) {
                System.err.println("MUST BE A NUMBER");
            }
            catch(ArrayIndexOutOfBoundsException r){
                System.err.print("THAT DOESN'T WORK TRY A DIFFERENT SPOT:  ");
            }
            /*Small if statement for the rare chance that the game results in a tie*/
            if(turn==25){
                active=false;
                System.out.println("TIE!");
            }
        }
    }

    /*The winChecker method which branches off to the different types of wins to see if any are true */
    private static boolean winChecker() {
        if (winVertical()|| winHorizontal() || winDiagonal()){ //see's if there is a vertical win or horizontal or diagonal
            return true;
        }
        else
            System.out.printf("PREVIOUS MOVE: COL%d  ROW:%d%n", playerCol+1,currentRow+1); //Prints the last players move so that the next player can see.
            return false;
    }

    /*Checks to see if there is a vertical win */
    private static boolean winVertical() {
        if(currentRow<3){//keeps from going out of bounds
            if (((three[currentRow+1][playerCol].equals(sym)) && (three[currentRow+2][playerCol].equals(sym)))) {//the only configuration possible for a vertical win
                return true; }}
        return false;
    }

    /*Checks to see if there is a horizontal win */
    private static boolean winHorizontal() {
    if(playerCol<3){//keeps in bounds
        if((three[currentRow][playerCol+1].equals(sym)) && (three[currentRow][playerCol+2].equals(sym))){//Possible horizontal win configuration 1
            return true;
        }}
    if(playerCol>1){
        if((three[currentRow][playerCol-1].equals(sym)) && (three[currentRow][playerCol-2].equals(sym))){//Possible horizontal win configuration 2
            return true;
        }}
    if(playerCol>0 && playerCol<4)
        if((three[currentRow][playerCol-1].equals(sym)) && (three[currentRow][playerCol+1].equals(sym))){//Possible horizontal win configuration 3
            return true;
        }
    return false;
    }


    /*Checks to see if there i a diagonal win */
    private static boolean winDiagonal() {
        if (currentRow < 3 && playerCol < 3) {//keeps in bounds
            if ((three[currentRow + 1][playerCol + 1].equals(sym)) && (three[currentRow + 2][playerCol + 2].equals(sym))) {//Possible diagonal win configuration 1
                return true;
            }
        }
        if (currentRow > 1 && playerCol > 1) {
            if ((three[currentRow - 1][playerCol - 1].equals(sym)) && (three[currentRow - 2][playerCol - 2].equals(sym))) {//Possible diagonal win configuration 2
                return true;
            }
        }
        if (currentRow < 3 && playerCol > 1) {
            if ((three[currentRow + 1][playerCol - 1].equals(sym)) && (three[currentRow + 2][playerCol - 2].equals(sym))) {//Possible diagonal win configuration 3
                return true;
            }
        }
        if(currentRow>1 && playerCol<3){
            if ((three[currentRow - 1][playerCol + 1].equals(sym)) && (three[currentRow - 2][playerCol + 2].equals(sym))) {//Possible diagonal win configuration 4
                return true;
            }
        }
        if(currentRow>0 && currentRow<4 && playerCol>0 && playerCol<4) {
            if ((three[currentRow + 1][playerCol + 1].equals(sym)) && (three[currentRow - 1][playerCol - 1].equals(sym))) {//Possible diagonal win configuration 5
                return true;
            }
            if ((three[currentRow - 1][playerCol + 1].equals(sym)) && (three[currentRow + 1][playerCol - 1].equals(sym))) {//Possible diagonal win configuration 6
                return true;
            }
        }
            return false;
    }

    /*This is the method that displays the "title" array which
     is the column numbers listed above the table
      */
    private static void title() {
        for(int m=0; m<5; m++){
            title[m] = (" |  " + (m + 1) + "  | ");
            System.out.printf(title[m]);
        }

        System.out.println();
    }

    /*Here is the method that creates the method which makes the
      table look like it is supposed to, and then print it
     */
    private static void displayTable()
    {for (int x = 0; x < 5; x++)
    {
        for (int y = 0; y < 5; y++) {
            if(three[x][y]==null){
                three[x][y]="   ";
            }
            System.out.printf(" | " + three[x][y] + " | ");
        }
        System.out.println();
    }
    }

    /*Here is the method that takes the input for the spot
     from the user and then it makes the spot have that
     player's token type placed in it.
     */
    private static void inputTable() {
        Scanner scan = new Scanner(System.in);
        System.out.printf(player + " %nENTER THE COLUMN NUMBER:  ");//Prompts for their input
        playerCol = (scan.nextInt() - 1); //gets it and decreases it by 1 to work for the array
        if(playerCol<5 && playerCol>=0) {//makes sure that it is in the bounds of the array

            if (playerCol == 0) {
                currentRow = colA;
                three[colA][0] = sym;
                if (colA + 1 == 0) {//in case they try to put a token into this column when it is full
                    System.out.println("Full Choose Other Column");
                } else {
                    colA--; //decreases the row number for the column(ie it moves "up" one position on the table)
                    turn++;//Moves the turn to allow for the other player to have their turn next
                }
            } else if (playerCol == 1) {
                currentRow = colB;
                three[colB][1] = sym;
                if (colB + 1 == 0) {
                    System.out.println("Full Choose Other Column");
                } else {
                    colB--;
                    turn++;
                }
            } else if (playerCol == 2) {
                currentRow = colC;
                three[colC][2] = sym;
                if (colC + 1 == 0) {
                    System.out.println("Full Choose Other Column");
                } else {
                    colC--;
                    turn++;
                }
            } else if (playerCol == 3) {
                currentRow = colD;
                three[colD][3] = sym;
                if (colD + 1 == 0) {
                    System.out.println("Full Choose Other Column");
                } else {
                    colD--;
                    turn++;
                }
            } else if (playerCol == 4) {
                currentRow = colE;
                three[colE][4] = sym;
                if (colE + 1 == 0) {
                    System.out.println("Full Choose Other Column");
                } else {
                    colE--;
                    turn++;
                }
            }
        }
    }
}







