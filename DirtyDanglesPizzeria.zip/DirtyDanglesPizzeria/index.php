<!DOCTYPE html>
<html lang="en">
	<head> <!-- Head Element -->
		<meta charset="utf-8" />
		<title>Create Your Pizza - Dirty Dangle's Pizzeria™</title> 
		<link rel="stylesheet"	href="css/styles.css"/>
	</head>
	<body> <!--Body Element -->
		<h1>Dirty Dangle's Pizzeria™</h1>
		<header><!--Header Element -->
			<img src="images/Leafs.PNG" height="20%" width="20%"  >	<!--Small image located at the top left of the web page -->	
			<form>
				<label for="search">Search For Order</label>
				<input name="search" id="search" type="search" />
				<button type="submit">Go</button>
			</form>
		</header>
		<main>
			<h2>Edit Payment Information</h2> 
			<form action="process-form.php" method="get">
				<fieldset>
					<legend>Information</legend> <!--All the inforamtion about the user being aquired is in this Fieldset -->
					<div>
						<label for="name">Name </label>
						<input type="text" name="name" id="name" size="25" required placeholder="Auston Matthews"  />
					</div>

					<div>
						<label for="phone">Phone Number</label>
						<input type="tel" name="phone" id="phone" size="25" required placeholder="(000)-000-000" />
					</div>
					<div>
						<label for="email">Email Address</label>
						<input type="text" name="email" id="email" size="25" required placeholder="Matthews34@Email.com"/>
					</div>
					<div>
							<label for="city">City</label>
							<input type="city" name="city" id="city" size="25" required placeholder="Toronto"/>
					</div>
					<div>
						<label for="address">Delivery Address</label>
						<input type="text" name="address" id="address" size="25" required placeholder="1000 Main Street " />
					</div>
					<div>
						<label for="number">Apartment/Room Number</label>
						<input type="number" name="number" id="number" required placeholder="Rm 34"/>
					</div>
						<legend>Credit Card Details</legend>
						<input type="radio" name="ccType" id="amex" value="American Express" />
						<label for="amex">American Express</label>
						<input type="radio" name="ccType" id="mc" value="MasterCard" />
						<label for="mc">MasterCard</label>
						<input type="radio" name="ccType" id="visa" value="VISA"/>
						<label for="visa">VISA</label>
						<br/>				
						<label for="ccNumber">Credit Card Number</label>
						<input id="ccNumber" type="text" name="ccNumber" required placeholder="1634-1634-1634-1634" />
				</fieldset>
				<fieldset> <!--All the items that can be customized about the pizza are in this Fieldset -->

					<legend>Pizza Customization</legend>

						<ul>
							<div>
								<label for="num" require>Number Of Pizzas </label>
								<input type="number" name="num" id="num" size="3" required default="1"/>
								<br/>
								<label for="Thick">Crust Thickness</label>
									<select name="Thick" id="Thick">
										<option value="thin crust">Thin Crust</option>
										<option value="thick crust">Thick Crust</option>
									</select>
								<br/>
								<label for="Shape">Pizza Shape</label>
									<select name="Shape" id="Shape">
										<option value="round">Round</option>
										<option value="square">Square</option>
									</select>
								<br/>

								<label for="size">Size</label>
								<select name="size" id="size">
									<option value="small">Small</option>
									<option value="regular">Regular</option>
									<option value="large">Large</option>
								</select>
								<br/>
								<label for="">Bake Level</label>
								<input type="range" id="rateInput" name="rating" min="0" max="10" step="1" />
								<output id="rateValue">5</output>
								<small>A higher bake level will result in A firm, more crunchy pizza</small>
								<br/>
							</div>
							<legend>Meats</legend>
							
							<input type="checkbox" name="topping1" id="topping1" value="Pepperoni" />
							<label for="topping1">Pepperoni</label>
							<input type="checkbox" name="topping2" id="topping2" value="Bacon" />
							<label for="topping2">Bacon</label>
							<input type="checkbox" name="topping3" id="topping3" value="Beef" />
							<label for="topping3">Beef</label>
							<input type="checkbox" name="topping[]" id="topping4" value="Chicken" />
							<label for="topping4">Chicken</label>
							<input type="checkbox" name="topping[]" id="topping5" value="Ham" />
							<label for="topping5">Ham</label>
							<input type="checkbox" name="topping[]" id="topping6" value="Tofu" />
							<label for="topping6">Tofu</label>
							<input type="checkbox" name="topping[]" id="topping7" value="Anchovies" />
							<label for="topping7">Anchovies</label>
						</ul>	
						<!--Catagory 2-->
						<ul>
							<legend>Dairy & Dairy Substitutes</legend>
							<input type="radio" name="topping[]" id="topping0" value="Cheese"/>
							<label for="topping0">Standard Cheese</label>							
							<input type="radio" name="topping[]" id="topping8" value="Extra Cheese" />
							<label for="topping8">Extra Cheese</label>
							<input type="checkbox" name="topping[]" id="topping9" value="Vegan" />
							<label for="topping9">Vegan Cheese</label>
							<input type="checkbox" name="topping[]" id="topping10" value="Goat Cheese" />
							<label for="topping10">Goat Cheese</label>
							<input type="checkbox" name="topping[]" id="topping11" value="Stuffed Crust" />
							<label for="topping11">Stuffed Crust</label>
						</ul>		
						<!--Catagory 3-->
						<ul>
							<legend>Fruits, Fungi & Vegetables</legend>
							<input type="checkbox" name="topping[]" id="topping13" value="Spinach" />
							<label for="topping13">Spinach</label>
							<input type="checkbox" name="topping[]" id="topping14" value="Pineapple" />
							<label for="topping14">Pineapple</label>
							<input type="checkbox" name="topping[]" id="topping15" value="Sweet Peppers" />
							<label for="topping15">Sweet Peppers</label>
							<input type="checkbox" name="topping[]" id="topping16" value="Spicy Peppers" />
							<label for="topping16">Spicy Peppers</label>
							<input type="checkbox" name="topping[]" id="topping18" value="Onions" />
							<label for="topping18">Onions</label>
							<input type="checkbox" name="topping[]" id="topping19" value="Mushrooms" />
							<label for="topping19">Mushrooms</label>
						</ul>
				</fieldset>	
				<fieldset>	<!--Any other information is in this Fieldset-->
					<legend>Additional Information</legend>
					<div>
						<label for="allergies">Allergies</label>
						<textarea name="allergies" id="allergies" placeholder="Type Allergies Here" cols="50" rows="5"></textarea>
						<br/>
						<label for="time" required>Desired Delivery Time</label>
						<input type="time" name="time" id="time"/>
						<br/>
						<label for="comments">Comments</label>
						<textarea name="comments" id="comments" placeholder="Type comments Here" cols="50" rows="10"></textarea>
					</div>
				</fieldset>
			<button type="submit">Order</button><!-- Goes to the process-form -->
			<button type="reset">Reset</button><!--Button to refresh the webpage to have blank input sections -->
			</form>
		</main>
		<footer><!-- Fine print -->
			<p><small><em>Dirty Dangle's Pizzeria™</em>. All rights reserved 
			<br/>
			<small><em>Dirty Dangle's Pizzeria™</em> cannot be held responsible for any injury or death as a result of an allergy that was not informed to staff</small>
			<br/>
			<small><em>Dirty Dangle's Pizzeria™</em> works in partnership with <em>Maple Leaf Sports And Entertainment</em> </small>
			</small></p>
		</footer>
		<script src="js/app.js"></script>
	</body>
</html>
