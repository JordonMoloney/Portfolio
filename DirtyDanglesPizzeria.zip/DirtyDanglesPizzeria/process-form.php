<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8" />
		<title>Order - Dirty Dangle's Pizzeria™</title>
		<link rel="stylesheet" href="css/styles2.css" />
	</head>
	<audio controls autoplay loop><!--Background Music -->
			<source src="Kernkraft.mp3" type="audio/mpeg">
	</audio>
	<body>
		<header>
			<h1>Dirty Dangle's Pizzeria™</h1>
			<h2>Order Information Updated</h2>
		</header>
<?php //Retrives the information from the index page 
	$name=$_GET['name']; 
	$city=$_GET['city'];
	$address=$_GET['address'];
	$number=$_GET['number'];
	$time=$_GET['time'];
	$toppingPrefs=$_GET['topping'];
	$size=$_GET['size'];
	$thick=$_GET['Thick'];
	$num=$_GET['num'];
	$shape=$_GET['Shape'];


	echo('<p>Thank you '.$name.' your order for '.$num.', '.$size.', '.$shape.', '.$thick.', pizza(s), has been recieved. It will be delivered to room '.$number. ' at ' .$address. ' in ' .$city. ' at '.$time. '.'); //Displays the information (other than the toppings) that is relavent to the page

	echo('<p>Your Pizaa Order Had:</p><ul>');
	foreach($toppingPrefs as $item){
		echo('<li>'.$item. '</li>');	
	} //Lists all the information that has been selected from the customizable toppings

	echo('</ul><p>We here at Dirty Dangles Pizzeria™ hope you enjoy your meal. Have a great day.</p>');
?>
	<p>
		<img src="images/Pizza paddle Matthews.jpg" width="100%" /> <!--Image in the paragraph -->
	</p>
	<footer>
		<p>
			<small><em>Dirty Dangle's Pizzeria™</em>. All rights reserved 
			<br/>
			<small><em>Dirty Dangle's Pizzeria™</em> cannot be held responsible for any injury or death as a result of an allergy that was not informed to staff</small>
			<br/>
			<small><em>Dirty Dangle's Pizzeria™</em> works in partnership with <em>Maple Leaf Sports And Entertainment</em> </small>
			</small>
		</p>
	</footer>
	</body>
</html>
